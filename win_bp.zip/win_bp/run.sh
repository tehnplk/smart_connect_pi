#!/bin/sh

cd /home/pi/win_bmi && ./win_bmi && killall -9 win_bmi
